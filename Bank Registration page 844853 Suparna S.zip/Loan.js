function validateform()
{
	var name=document.Bank_Loan.Name.value;
	var address=document.Bank_Loan.address.value;

	if (name==null||name=="") {
		alert("Name can't be empty");
		return false;
	}

	if (address.length==0||address==null) {
		alert("address can't be empty");
		return false;
	}
	else if (address.length>250) {
		alert("address can't exceed 250 characters");
		return false;
	}
	

}