  function validate(){
    var name=document.form.name.value;
    var pwd=document.form.pwd.value;
    if(name==null||name.length==0||name=="")
    {
      alert("name cant be empty");
      return false;
    }
    if(pwd.length<7 || pwd.length>8) 
    {
    	alert("Password must have min 7 and max 8 characters");
      return false;
    }
   }