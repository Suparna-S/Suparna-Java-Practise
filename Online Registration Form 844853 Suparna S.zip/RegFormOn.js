function validateform()
{
	var name=document.OnlineReg.username.value;
	var password=document.OnlineReg.password.value;
	var address=document.OnlineReg.address.value;
	var place=document.OnlineReg.place.value;
	var language=document.querySelector('input[name="language[]"]:checked');

	if (name==null||name=="") {
		alert("Name can't be empty");
		return false;
	}
	if (password.length<8||password.length>9) {
		alert("password must be of min 8 char and max 9 char");
		return false;
		}
	if (address.length==0||address==null) {
		alert("address can't be empty");
		return false;
	}
	else if (address.length>250) {
		alert("address can't exceed 250 characters");
		return false;
	}
	if (place=="Select") {
		alert("please Select a place");
		return false;
	}	
	if(!language){
		alert("Select a language");
		return false;
	}
}